package edu.mum.cs544.l02.model;

public enum Rating {
	NONE, BAD, GOOD, EXCELENT
}
